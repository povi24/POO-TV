package Feature;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import fileio.ActionsInputData;
import fileio.MoviesInputData;
import fileio.UsersInputData;
import helpers.LiveInfo;

import java.util.ArrayList;

public final class Like {
    private final ObjectMapper objectMapper = new ObjectMapper();


    public static void like(final ActionsInputData command, final ArrayList<UsersInputData> users,
                            final ArrayList<MoviesInputData> movies, final ArrayNode output) {

        /**
         * We make sure that we can perform the action(we are on the see details page)
         */
        ObjectMapper objectMapper = new ObjectMapper();
        ArrayList<MoviesInputData> allMovies = LiveInfo.getInstance().getCurrentMovieList();

        if (LiveInfo.getInstance().getCurrentPage().getPageType().equals("see details")) {
            ObjectNode objectNode = objectMapper.createObjectNode();


            for (int i = 0; i < allMovies.size(); i++) {
                MoviesInputData movie = allMovies.get(i);

                if (movie.getCountriesBanned().contains(LiveInfo.getInstance().getCurrentUser().getCredentials().getCountry())) {
                    allMovies.remove(movie);
                    i--;
                }
            }

            ArrayList<MoviesInputData> moviesForPrinting = new ArrayList<>();
            //all movies e lista userului curent
            if (allMovies.contains(command.getMovie())) {
                for (int j = 0; j < allMovies.size(); j++) {

                    {
                        /**
                         * we make a list with the movie we want to see the details from
                         */

                        ArrayList<MoviesInputData> list = new ArrayList<>();
                        MoviesInputData movie = allMovies.get(j);
                        list.add(movie);
                        LiveInfo.getInstance().setCurrentMovieList(list);
                        moviesForPrinting = new ArrayList<>();
                        moviesForPrinting.add(new MoviesInputData(movie));
                        //in movies for printig voi avea doar un film mereu si trebuie sa fac asa in toate metodele de la see details
                    }
                }

                /**
                 * We first verify if the watch command was executed
                 */
                for (int k = 0; k < LiveInfo.getInstance().getCurrentUser().getWatchedMovies().size(); k++) {
                    if (!LiveInfo.getInstance().getCurrentUser().getLikedMovies().contains(command.getMovie())) {
                        /**
                         * We modify the liked section of the user
                         */

                        LiveInfo.getInstance().getCurrentUser().getLikedMovies().add(LiveInfo.getInstance().getCurrentUser().getLikedMovies().get(k));

                        LiveInfo.getInstance().getCurrentUser().getLikedMovies().get(k).setNumLikes(LiveInfo.getInstance().getCurrentUser().getLikedMovies().get(k).getNumLikes() + 1);
                    }
                }

                objectNode.putPOJO("error", null);
                objectNode.putPOJO("currentMoviesList", moviesForPrinting);
                objectNode.putPOJO("currentUser", new UsersInputData(LiveInfo.getInstance().getCurrentUser()));
                output.addPOJO(objectNode);


            } else {
                objectNode.putPOJO("error", "Error");
                objectNode.putPOJO("currentMoviesList", new ArrayList<>());
                objectNode.putPOJO("currentUser", null);
                output.addPOJO(objectNode);
            }


        } else {
            ObjectNode objectNode = objectMapper.createObjectNode();
            objectNode.putPOJO("error", "Error");
            objectNode.putPOJO("currentMoviesList", new ArrayList<>());
            objectNode.putPOJO("currentUser", null);
            output.addPOJO(objectNode);
        }

    }
}
