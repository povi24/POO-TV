package Feature;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import fileio.ActionsInputData;
import fileio.MoviesInputData;
import fileio.UsersInputData;
import helpers.Constants;
import helpers.LiveInfo;

import java.util.ArrayList;

public final class Purchase {
    private final ObjectMapper objectMapper = new ObjectMapper();


    private static void purchase(final ActionsInputData command, final ArrayList<UsersInputData> users,
                                 final ArrayList<MoviesInputData> movies, final ArrayNode output) {
        /**
         * We make sure that we can perform the action(we are on the see details page)
         */
        ObjectMapper objectMapper = new ObjectMapper();
        if(LiveInfo.getInstance().getCurrentPage().getPageType().equals("see details")) {

            ObjectNode objectNode = objectMapper.createObjectNode();
            ArrayList<MoviesInputData> allMovies = LiveInfo.getInstance().getCurrentMovieList();
//            for (int i = 0; i < allMovies.size(); i++) {
//                MoviesInputData movie = allMovies.get(i);
//
//                if (movie.getCountriesBanned().contains(LiveInfo.getInstance().getCurrentUser().getCredentials().getCountry())) {
//                    allMovies.remove(movie);
//                    i--;
//                }
//            }

            ArrayList<MoviesInputData> moviesForPrinting = new ArrayList<>();
            //all movies e lista userului curent

            //adaugam toate numele filmelor curente
            ArrayList<String> movieNames = new ArrayList<>();
            //indexul filmului pentru care vrem detaliile
            int movieIndex = 0;
            int counter = 0;
            for (MoviesInputData movie : allMovies) {
                movieNames.add(movie.getName());
                if (movie.getName().equals(command.getMovie())) {
                    movieIndex = counter;
                }
                counter++;
            }


            if(movieNames.contains(command.getMovie())) {

                /**
                 * we make a list with the movie we want to see the details from
                 */

                //lista CU UN SINGUR FILM PRACTIC
                ArrayList<MoviesInputData> list = new ArrayList<>();
                MoviesInputData movie = allMovies.get(movieIndex);
                list.add(movie);
                LiveInfo.getInstance().setCurrentMovieList(list);

                moviesForPrinting = new ArrayList<>();
                moviesForPrinting.add(new MoviesInputData(movie));
                //in movies for printig voi avea doar un film mereu si trebuie sa fac asa in toate metodele de la see details

            }


                if(LiveInfo.getInstance().getCurrentUser().getCredentials().getAccountType().equals("premium")
                || LiveInfo.getInstance().getCurrentUser().getNumFreePremiumMovies() == Constants.NUM_OF_FREE_PREMIUM_MOVIES) {
                    LiveInfo.getInstance().getCurrentUser().setNumFreePremiumMovies(Constants.NUM_OF_FREE_PREMIUM_MOVIES - 1);
                } else {
                    LiveInfo.getInstance().getCurrentUser().setTokensCount(LiveInfo.getInstance().getCurrentUser().getTokensCount() - 2);
                }

                /**
                 * we add the film in the purchased section
                 */
                LiveInfo.getInstance().getCurrentUser().getPurchasedMovies().add(LiveInfo.getInstance().getCurrentMovieList().get(0));

                objectNode.putPOJO("error", null);
                objectNode.putPOJO("currentMoviesList", moviesForPrinting);
                objectNode.putPOJO("currentUser", new UsersInputData(LiveInfo.getInstance().getCurrentUser()));
                output.addPOJO(objectNode);




            } else {
                objectNode.putPOJO("error", "Error");
                objectNode.putPOJO("currentMoviesList", new ArrayList<>());
                objectNode.putPOJO("currentUser", null);
                output.addPOJO(objectNode);
            }

        } else {
            ObjectNode objectNode = objectMapper.createObjectNode();
            objectNode.putPOJO("error", "Error");
            objectNode.putPOJO("currentMoviesList", new ArrayList<>());
            objectNode.putPOJO("currentUser", null);
            output.addPOJO(objectNode);

        }


    }

}
