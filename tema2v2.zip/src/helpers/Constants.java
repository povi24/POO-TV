package helpers;

/**
 * This class contains the constants that are needed
 */
public final class Constants {
    private Constants() {
    }
    public static final int NUM_OF_FREE_PREMIUM_MOVIES = 15;
}
