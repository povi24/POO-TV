package Feature;

import Pages.Page;
import Pages.VerifyType;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import fileio.ActionsInputData;
import fileio.MoviesInputData;
import fileio.UsersInputData;

import java.util.ArrayList;

public final class Login {
    private final ObjectMapper objectMapper= new ObjectMapper();
//    private VerifyType pageType = new VerifyType();
    private ArrayList<MoviesInputData> currMoviesList = new ArrayList<>();
    private UsersInputData currUser;
    private Page currPage = pageType.verifyType("HomePageNon");
    private static final VerifyType pageType = new VerifyType();


    public void login(final ActionsInputData command, final ArrayList<UsersInputData> users,
                      final ArrayList<MoviesInputData> movies, final ArrayNode output) {
        /**
         * We make sure that we can perform the action(we are on the login page)
         */
        if(getCurrPage().getPageType().equals("login")) {
            /**
             * Action is performed successfully on the login page
             */
            for(int i = 0; i < users.size(); i++) {
                if (users.get(i).getCredentials().getName().
                        equals(command.getCredentials().getName())) {
                    if(users.get(i).getCredentials().getPassword().
                            equals(command.getCredentials().getPassword())) {
                        /**
                         * User has the right username and password, so we set him as
                         * the current user
                         */
                        setCurrUser(users.get(i));
                        setCurrPage(pageType.verifyType("HomePage"));

                        ObjectNode objectNode = objectMapper.createObjectNode();
                        objectNode.putPOJO("error", null);
                        objectNode.putPOJO("currentMoviesList", new ArrayList<>());
                        objectNode.putPOJO("currentUser", new UsersInputData(getCurrUser()));
                        output.addPOJO(objectNode);
                    }
                }
            }
        } else {
            ObjectNode objectNode = objectMapper.createObjectNode();
            objectNode.putPOJO("error", "Error");
            objectNode.putPOJO("currentMoviesList", new ArrayList<>());
            objectNode.putPOJO("currentUser", null);
            output.addPOJO(objectNode);
        }

        /**
         * Login has failed
         */
        for(int i = 0; i < users.size(); i++) {
            if (!users.get(i).getCredentials().getName().
                    equals(command.getCredentials().getName())) {
                ObjectNode objectNode = objectMapper.createObjectNode();
                objectNode.putPOJO("error", "Error");
                objectNode.putPOJO("currentMoviesList", new ArrayList<>());
                objectNode.putPOJO("currentUser", null);
                output.addPOJO(objectNode);
                setCurrPage(pageType.verifyType("HomePageNon"));
            }
        }
    }

    public ObjectMapper getObjectMapper() {
        return objectMapper;
    }

    public ArrayList<MoviesInputData> getCurrMoviesList() {
        return currMoviesList;
    }

    public void setCurrMoviesList(final ArrayList<MoviesInputData> currMoviesList) {
        this.currMoviesList = currMoviesList;
    }

    public UsersInputData getCurrUser() {
        return currUser;
    }

    public void setCurrUser(final UsersInputData currUser) {
        this.currUser = currUser;
    }

    public Page getCurrPage() {
        return currPage;
    }

    public void setCurrPage(final Page currPage) {
        this.currPage = currPage;
    }
}
