package Feature;

import Pages.Page;
import Pages.VerifyType;
import com.fasterxml.jackson.databind.ObjectMapper;
import fileio.MoviesInputData;
import fileio.UsersInputData;

import java.util.ArrayList;

public final class Register {
    private final ObjectMapper objectMapper= new ObjectMapper();
    //    private VerifyType pageType = new VerifyType();
    private ArrayList<MoviesInputData> currMoviesList = new ArrayList<>();
    private UsersInputData currUser;
    private Page currPage = pageType.verifyType("HomePageNon");
    private static final VerifyType pageType = new VerifyType();


}
